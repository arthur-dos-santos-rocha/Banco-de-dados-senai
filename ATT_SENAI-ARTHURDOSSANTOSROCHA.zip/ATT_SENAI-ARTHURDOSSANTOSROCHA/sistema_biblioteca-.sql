CREATE DATABASE IF NOT EXISTS biblioteca_senai;
USE biblioteca_senai;

DROP PROCEDURE IF EXISTS sp_RegistrarDevolucao;
DROP FUNCTION IF EXISTS fn_CalcularAtraso;
DROP TABLE IF EXISTS emprestimos;
DROP TABLE IF EXISTS leitores;
DROP TABLE IF EXISTS livros;


CREATE TABLE livros (
    id_livro INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    autor VARCHAR(100) NOT NULL
);

CREATE TABLE leitores (
    id_leitor INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE emprestimos (
    id_emprestimo INT AUTO_INCREMENT PRIMARY KEY,
    id_livro INT NOT NULL,
    id_leitor INT NOT NULL,
    data_emprestimo DATE NOT NULL,
    data_prevista DATE NOT NULL,
    data_devolucao DATE NULL,
    CONSTRAINT fk_emprestimos_livros FOREIGN KEY (id_livro) REFERENCES livros(id_livro),
    CONSTRAINT fk_emprestimos_leitores FOREIGN KEY (id_leitor) REFERENCES leitores(id_leitor)
);


INSERT INTO livros (titulo, autor) VALUES
('Wetsn', 'DBWTESN'),
('AS AVENTURAS DE LUAN', 'ERIK DO VALE'),
('BRASIL', 'SR.PEDRO');

INSERT INTO leitores (nome, email) VALUES
('ARTHUR ', 'arthur@email.com'),
('Bruno ', 'bruno@email.com'),
('luan ', 'luan.senai@email.com');


INSERT INTO emprestimos (id_livro, id_leitor, data_emprestimo, data_prevista, data_devolucao) VALUES
(1, 1, DATE_SUB(CURRENT_DATE, INTERVAL 20 DAY), DATE_SUB(CURRENT_DATE, INTERVAL 13 DAY), DATE_SUB(CURRENT_DATE, INTERVAL 10 DAY)),
(2, 2, DATE_SUB(CURRENT_DATE, INTERVAL 15 DAY), DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), NULL);


SELECT le.nome AS leitor, li.titulo AS livro, em.data_emprestimo
FROM emprestimos em
INNER JOIN leitores le ON le.id_leitor = em.id_leitor
INNER JOIN livros li ON li.id_livro = em.id_livro;


SELECT le.nome AS leitor, li.titulo AS livro
FROM leitores le
LEFT JOIN emprestimos em ON em.id_leitor = le.id_leitor
LEFT JOIN livros li ON li.id_livro = em.id_livro
ORDER BY le.id_leitor;


SELECT le.nome AS leitor, li.titulo AS livro, em.data_prevista
FROM emprestimos em
INNER JOIN leitores le ON le.id_leitor = em.id_leitor
INNER JOIN livros li ON li.id_livro = em.id_livro
WHERE em.data_devolucao IS NULL;


DELIMITER $$
CREATE FUNCTION fn_CalcularAtraso(p_id_emprestimo INT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE v_data_prevista DATE;
    DECLARE v_data_referencia DATE;
    DECLARE v_atraso INT;

    SELECT data_prevista, COALESCE(data_devolucao, CURRENT_DATE)
      INTO v_data_prevista, v_data_referencia
    FROM emprestimos
    WHERE id_emprestimo = p_id_emprestimo;

    SET v_atraso = DATEDIFF(v_data_referencia, v_data_prevista);

    IF v_atraso < 0 THEN
        SET v_atraso = 0;
    END IF;

    RETURN v_atraso;
END$$


CREATE PROCEDURE sp_RegistrarDevolucao(IN p_id_emprestimo INT)
BEGIN
    UPDATE emprestimos
    SET data_devolucao = CURRENT_DATE
    WHERE id_emprestimo = p_id_emprestimo
      AND data_devolucao IS NULL;

    SELECT id_emprestimo,
           data_devolucao,
           fn_CalcularAtraso(p_id_emprestimo) AS dias_atraso
    FROM emprestimos
    WHERE id_emprestimo = p_id_emprestimo;
END$$
DELIMITER ;

SELECT fn_CalcularAtraso(1) AS atraso_emprestimo_devolvido;
SELECT fn_CalcularAtraso(2) AS atraso_emprestimo_em_aberto;

